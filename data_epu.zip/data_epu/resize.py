import os
from PIL import Image

# Đường dẫn tới thư mục chứa ảnh gốc
input_dir = './'

# Đường dẫn tới thư mục chứa ảnh đã resize
output_dir = './'

# Kích thước mới của ảnh
new_size = (1, 1)

# Lặp qua toàn bộ các file ảnh trong thư mục đầu vào
for filename in os.listdir(input_dir):
    # Kiểm tra nếu đây là file ảnh (có đuôi .jpg, .png, ...)
    if filename.endswith('.jpg') or filename.endswith('.png'):
        # Đọc ảnh từ file
        img = Image.open(os.path.join(input_dir, filename))

        # Resize ảnh
        img = img.resize(new_size)

        # Lưu ảnh vào thư mục đầu ra
        img.save(os.path.join(output_dir, filename))

# import os

# path = "./Newfolder"  # Thay đổi đường dẫn đến thư mục của bạn tại đây
# count = 1

# for filename in os.listdir(path):
#     if filename.endswith(".jpg"):
#         new_name = f"image_huhu{count}.jpg"
#         os.rename(os.path.join(path, filename), os.path.join(path, new_name))
#         count += 1